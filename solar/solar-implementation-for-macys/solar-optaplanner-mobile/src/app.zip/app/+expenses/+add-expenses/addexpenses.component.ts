import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ExpensesServices } from '../expenses.service';
import { IMyOptions, IMyDateModel, IMyDate } from 'mydatepicker';
import { FormsModule, FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { DomSanitizer } from '@angular/platform-browser';
declare var cordova: any;

declare let navigator: any;
declare var Camera: any;

@Component({
    selector: 'add-expenses',
    templateUrl: './addexpenses.component.html',
    styles: [`
      .close-tag{
              float: right;
        background:aqua;
        width: 15px;
        text-align: center; 
        overflow:hidden; 
        }
        .ui-overlay-c {
            background-color: rgba(0, 0, 0, 0.5);
            position: fixed;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            text-align: center;
        }
        .loading {
          position: absolute;
          top: 50%;
          left: 50%;
        }
        .loading-bar {
         
          display: inline-block;
          width: 4px;
          height: 18px;
          border-radius: 4px;
          animation: loading 1s ease-in-out infinite;
        }
        .loading-bar:nth-child(1) {
          background-color: #3498db;
          animation-delay: 0;
        }
        .loading-bar:nth-child(2) {
          background-color: #c0392b;
          animation-delay: 0.09s;
        }
        .loading-bar:nth-child(3) {
          background-color: #f1c40f;
          animation-delay: .18s;
        }
        .loading-bar:nth-child(4) {
          background-color: #27ae60;
          animation-delay: .27s;
        }
        
        @keyframes loading {
          0% {
            transform: scale(1);
          }
          20% {
            transform: scale(1, 2.2);
          }
          40% {
            transform: scale(1);
          }
        }
    
    `]
})
export class AddExpensesComponent implements OnInit {
    public complexForm: FormGroup;
    receiptImg: any = '';
    formValidate = false;
    expensesTypes: any = [{
        "id": 1,
        "expenseType": "Food"
    },
    {
        "id": 2,
        "expenseType": "Gas"
    },
    {
        "id": 3,
        "expenseType": "Hotel"
    },
    {
        "id": 4,
        "expenseType": "Others"
    }]


    addExpenseObj: any = {
        "loadNumber": {
            "apptNbr": ''
        },
        "driverId": {
            "id": localStorage.getItem('driverData')
        },
        "expenseTypeId": {
            "id": ''
        },
        "amount": 0,
        "billDate": "2019-12-08",
        "billImage": ''
    }


    constructor(private _sanitizer: DomSanitizer, private fb: FormBuilder, public router: Router, public _expensesServices: ExpensesServices, private formBuilder: FormBuilder) { }


    private readonly myDatePickerOptions: IMyOptions = {
        openSelectorOnInputClick: true,
        inline: false,
        disableSince: { year: (new Date()).getFullYear(), month: (new Date()).getMonth() + 1, day: (new Date()).getDate() + 1 },
        dateFormat: 'yyyy-mm-dd',
        showTodayBtn: false,
        showClearDateBtn: false,
        editableDateField: false,
        height: '30px',
        selectionTxtFontSize: '14px',
        indicateInvalidDate: true,
    };
    driverId: any;
    ngOnInit() {
        this.complexForm = this.fb.group({
            'loadNumbers': new FormControl(null, Validators.required),
            'expenseType': new FormControl(null, Validators.required),
            'amount': new FormControl(null, [Validators.required, Validators.pattern('^[0-9]+([.][0-9]+)?$')]),
            'billDate': new FormControl(null, Validators.required),
            'image': new FormControl(null),

        })
        this.driverId = localStorage.getItem('driverData');
        this.getLoadNumbers();
    }
    loadNumbersList: any = [];

    getLoadNumbers() {
        this._expensesServices.getLoadNumberByDriverid(this.driverId).subscribe((data: any) => {
            if (data.error == null) {
                this.loadNumbersList = data.data;
                console.log(this.loadNumbersList)
            }
        })
    }


    loaderBtn = false;
    base64Data: any = '';
    takePicture() {
        this.loaderBtn = true;
        if (navigator != undefined) {
            navigator.camera.getPicture(
                (base64string) => {
                    this.base64Data = base64string;
                    this.addExpenseObj.billImage = this._sanitizer.bypassSecurityTrustResourceUrl('data:image/jpg;base64,'
                        + base64string);
                        this.loaderBtn = false;
                },
                (error) => {
                    this.loaderBtn = false;
                    alert("Unable to obtain picture: " + error);
                }, {
                    quality: 25,
                    allowEdit: true,
                    destinationType: Camera.DestinationType.DATA_URL,
                    sourceType: Camera.PictureSourceType.CAMERA,
                    encodingType: Camera.EncodingType.PNG,
                    targetWidth: 100,
                    targeHeight: 100,
                    correctOrientation: true
                }
            );

        }
    }
    deleteReceiptImg() {
        this.addExpenseObj.billImage = null;
    }

    addExpenceDetailsSuccessMsg: any;
    addExpenceDetailsErrorMsg: any;
    addExpensesDetails() {
       

        if (this.complexForm.valid) {
            this.addExpenseObj.billDate = this.complexForm.value.billDate["jsdate"];
            this.addExpenseObj.billImage=this.base64Data;
            const formData: FormData = new FormData();
            formData.append('expenseDetails', JSON.stringify(this.addExpenseObj))
            this._expensesServices.addExpenses(this.addExpenseObj).subscribe((data: any) => {
                if (data.error == null) {
                    this.addExpenceDetailsSuccessMsg = "Expenses Added Successfully";
                    setTimeout(() => {
                        this.addExpenceDetailsSuccessMsg = '';
                        this.router.navigate(['./expenses'])
                    }, 3000)
                } else {
                    this.addExpenceDetailsErrorMsg = data.error.message;
                    setTimeout(() => {
                        this.addExpenceDetailsErrorMsg = '';
                        this.router.navigate(['./expenses'])
                    }, 3000)
                }
            })
        } else {
            this.formValidate = true
        }
    }
}