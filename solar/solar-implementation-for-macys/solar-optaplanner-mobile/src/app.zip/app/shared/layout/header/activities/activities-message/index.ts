export { ActivitiesMessageComponent } from './activities-message.component';
