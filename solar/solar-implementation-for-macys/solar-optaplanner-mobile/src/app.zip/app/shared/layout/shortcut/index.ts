export {ShortcutComponent} from './shortcut.component';
