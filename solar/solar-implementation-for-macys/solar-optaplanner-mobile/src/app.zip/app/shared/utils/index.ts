/**
 * Created by griga on 6/20/16.
 */


export {MomentPipe,MomentPipeFromNow} from './moment.pipe'
