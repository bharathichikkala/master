export {ChartJsComponent} from './chart-js.component';
