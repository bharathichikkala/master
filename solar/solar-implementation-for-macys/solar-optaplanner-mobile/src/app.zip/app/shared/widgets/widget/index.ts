export {WidgetComponent} from './widget.component';
