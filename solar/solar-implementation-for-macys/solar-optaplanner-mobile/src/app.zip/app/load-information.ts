export let globalObj: any = {
    loadNumber: '',
    acceptedLoadNumber: '',
    loadObj: '',
    scannedCartonId: '',
    scannedCartonQRCode: '',
    postSkidId: '',
    preInspectionStatus: ''
}

