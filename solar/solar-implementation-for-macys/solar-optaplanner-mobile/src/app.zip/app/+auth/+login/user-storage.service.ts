export class userStorageService {
  public userData;
}