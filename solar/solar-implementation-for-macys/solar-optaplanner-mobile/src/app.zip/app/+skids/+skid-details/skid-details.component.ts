import { Component } from '@angular/core';

@Component({
    selector: 'skid-details',
    templateUrl: './skid-details.component.html'
})

export class SkidDetailsComponent {

}