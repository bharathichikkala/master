import { Component } from '@angular/core';
import { globalObj } from '../../load-information';
import { Router } from '@angular/router';
import { SkidServices } from '../skids.service'
@Component({
    selector: 'skid-list',
    templateUrl: './skid-list.component.html',
    providers: [SkidServices]
})

export class SkidListComponent {
    loadObj: any;
    acceptBtnStatus: any;
    inspectionStatus: any;
    constructor(public _router: Router, public _skidServices: SkidServices) { }
    skidDrops: any = [];
    ngOnInit() {

         
        //    console.log(this.acceptBtnStatus)

        this.inspectionStatus = globalObj.preInspectionStatus;
        if (globalObj.acceptedLoadNumber == globalObj.loadNumber) {
            globalObj.acceptedLoadNumber == '' ? this.acceptBtnStatus = null : this.acceptBtnStatus = globalObj.acceptedLoadNumber;
        }

        if (globalObj.loadNumber) {
            this._skidServices.getSkidsByloadNumber(globalObj.loadNumber).subscribe((data) => {
                this.skidDrops = data.data;
            })
        } else {
            this._router.navigate(['./loads'])
        }
    }

    acceptLoad() {
        if (globalObj.acceptedLoadNumber == '') {
            this._skidServices.setLoadAccept(globalObj.loadNumber, 4).subscribe(
                data => {
                    globalObj.acceptedLoadNumber = globalObj.loadNumber;
                    globalObj.inspectionType = 1;
                    this._router.navigate(['/inspection/inspectionDetails', globalObj.loadNumber]);
                })
        } else {
            alert('already load accepted');
        }
    }

    goBack() {
        this._router.navigate(['/loads'])
    }
    gotoMaps() {
        this._router.navigate(['./maps'])
    }
    goToSkids() {
        globalObj.acceptedLoadNumber = globalObj.loadNumber;
        globalObj.inspectionType = 1;
        this._router.navigate(['/inspection/inspectionDetails', globalObj.acceptedLoadNumber])
    }


}