import { NgModule } from '@angular/core';
import { SmartadminModule } from '../shared/smartadmin.module';
import { routing } from './skids.routing';

@NgModule({
    imports: [routing, SmartadminModule],
    declarations: [],
    exports: [],

})
export class SkidsModule { }
